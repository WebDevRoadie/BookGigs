from django.apps import AppConfig


class GigappConfig(AppConfig):
    name = 'gigApp'
