from django.db import models
import re, bcrypt
EMAIL_REGEX = re.compile('^[_a-z0-9-]+(.[_a-z0-9-]+)@[a-z0-9-]+(.[a-z0-9-]+)(.[a-z]{2,4})$')

class LogManager(models.Manager):
    def validate(self, form):
        errors = {}
        if len(form['first_name']) < 2:
            errors["first_name"] = "First Name should be at least 2 characters long"

        if len(form['last_name']) < 2:
            errors["last_name"] = "Last Name should be at least 2 characters long"

        if not EMAIL_REGEX.match(form['email']):    
            errors['email'] = ("Invalid email address!")

        email_check = self.filter(email=form['email'])
        if email_check:
            errors['email'] ="Email already in use"

        if len(form['password']) < 8:
            errors['password'] = 'Password must be at least 8 characters'
            
        if form['password'] != form['confirm_password']:
            errors['password'] = 'Passwords do not match'

        return errors
        
    def authenticate(self, email, password):
        users = self.filter(email=email)
        if not users:
            return False
        
        user= users[0]
        return bcrypt.checkpw(password.encode(), user.password.encode())

    def register(self, form):
        pw = bcrypt.hashpw(form['password'].encode(), bcrypt.gensalt()).decode()
        return self.create(
            first_name = form['first_name'],
            last_name = form['last_name'],
            email = form['email'],
            password = pw
        )

class User(models.Model):
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=255)

    objects = LogManager()

class Gig(models.Model):
    creator = models.ForeignKey(User,related_name= "gigs", on_delete=models.CASCADE)
    event = models.CharField(max_length=255)
    location = models.CharField(max_length=255)
    dates = models.CharField(max_length=255)
    department = models.CharField(max_length=255)
    duration_times = models.CharField(max_length=255)
    labor_coordinator = models.CharField(max_length=255)
    contact_info = models.CharField(max_length=255)
    created_at = models.DateField(auto_now_add=True)
    updated_at = models.DateField(auto_now=True)
