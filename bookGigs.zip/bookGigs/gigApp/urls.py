from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('registration', views.registration),
    path('login', views.login),
    path('logout', views.logout),
    path('list', views.list),
    path('details/<int:id>', views.details),
    path('add', views.add),
    path('delete/<int:id>', views.delete),
    path('edit/user/<int:id>', views.edit_user),
    path('edit/gig/<int:id>', views.render_gig),
    path('editgig/<int:id>', views.edit_gig)
]