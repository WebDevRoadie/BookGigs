from django.shortcuts import render, redirect
from .models import *
from django.contrib import messages

def index(request):
    return render(request,'log_reg.html')

def registration(request):
    if request.method == "GET":
        return redirect('/')
    errors = User.objects.validate(request.POST)
    if errors:
        for e in errors.values():
            messages.error(request, e)
        return redirect('/')
    else:
        new_user = User.objects.register(request.POST)
        request.session['user_id'] = new_user.id
        request.session['user_name'] = new_user.first_name
        messages.success(request, "You have successfully registered!")
    return redirect('/list')
    

def login(request):
    if request.method == "GET":
        return redirect('/')
    if not User.objects.authenticate(request.POST['email'], request.POST['password']):
        messages.error(request, 'Invalid Email/Password')
        return redirect('/')
    user = User.objects.get(email=request.POST['email'])
    request.session['user_id'] = user.id
    request.session['user_name'] = user.first_name
    messages.success(request, "You have successfully logged in!")
    print(user_id)
    return redirect('/list')
    

def logout(request):
    request.session.clear()
    return redirect('/')

def list(request):
    if 'user_id' not in request.session:
        return redirect('/')
    user = User.objects.get(id=request.session['user_id'])
    context = {
        'user_id': user,
        'list': Gig.objects.all()
    }
    return render(request, 'list.html', context)

def details(request,id):
    if 'user_id' not in request.session:
        return redirect('/')
    user = User.objects.get(id=request.session['user_id'])
    context = {
        'user_id': user,
        'gig': Gig.objects.get(id=id)
        }
    return render(request, 'details.html', context)

def add(request):
    if request.method == "GET":
        if 'user_id' not in request.session:
            return redirect('/')
        user = User.objects.get(id=request.session['user_id'])
        context = {
            'user_id': user,
        }
        return render(request, 'add.html', context)
    else:
        user = User.objects.get(id=request.session["user_id"])
        gig = Gig.objects.create(
        creator = user,
        event = request.POST['event'],
        location = request.POST['location'],
        dates = request.POST['dates'],
        department = request.POST['department'],
        duration_times = request.POST['duration_times'],
        labor_coordinator = request.POST['labor_coordinator'],
        contact_info = request.POST['contact_info']
        )
    return redirect ('/list')

def edit_user(request,id):
    user_id = User.objects.get(id=request.session['user_id'])
    if request.method == "GET":
        context = {
            'gig' : Gig.objects.get(id=request.session['user_id']),
            'user_id': User.objects.get(id=request.session['user_id'])
        }
        return render(request,'edit.html', context)
    else:
        edit_user = User.objects.get(id=request.session['user_id'])
        edit_user.first_name = request.POST['first_name']
        edit_user.last_name = request.POST['last_name']
        edit_user.email = request.POST['email']
        edit_user.save()
    return redirect(f'/edit/user/{user_id.id}')

def edit_gig(request,id):
    gig = Gig.objects.get(id=id)
    gig.creator = User.objects.get(id=request.session['user_id'])
    gig.event = request.POST['event']
    gig.location = request.POST['location']
    gig.dates = request.POST['dates']
    gig.department = request.POST['department']
    gig.duration_times = request.POST['duration_times']
    gig.labor_coordinator = request.POST['labor_coordinator']
    gig.contact_info = request.POST['contact_info']
    gig.save()
    return redirect(f'/list')  

def render_gig(request,id):
    context = {
        'gig' : Gig.objects.get(id=request.session['user_id']),
    }
    return render (request,'editgig.html',context)

def delete(request,id):
    this_user=User.objects.get(id=request.session['user_id'])
    
    destroyed = Gig.objects.get(id=id)
    destroyed.delete()
    return redirect(f'/edit/user/{this_user.id}')
    

